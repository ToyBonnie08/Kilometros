<?php    
header('Content-Type: application/json');
include('conexion.php');

// Obtener rutas activas tipo "Ruta"
$sql = "SELECT id, Zona FROM tiporuta WHERE activo=1 AND LEFT(Zona, 4)='Ruta' ORDER BY Zona ASC";
$result = $conexion->query($sql);

$zonas = [];

while ($row = $result->fetch_assoc()) {
    $zonas[$row['id']] = [
        'Zona' => $row['Zona'],
        'Diario' => [],
        'Semanal' => [],
        'Mensual' => []
    ];
}

// Obtener registros de kilometrajes
$sqlkm = "SELECT tiporuta_id, fecha, kmsinicial, kmsfinal FROM vehiculokms ";
$resultkm = $conexion->query($sqlkm);

while ($row = $resultkm->fetch_assoc()) {
    $id = $row['tiporuta_id'];
    $fecha = $row['fecha'];
    $dia = date('Y-m-d', strtotime($fecha));
    $semana = date('Y-\WW', strtotime($fecha)); // Formato semana ISO (ej. 2025-W20)
    $mes = date('Y-m', strtotime($fecha));      // Formato mes (ej. 2025-05)

    $kms_inicial = (float)$row['kmsinicial'];
    $kms_final = (float)$row['kmsfinal'];

    $kms_recorridos = $kms_final - $kms_inicial;
    if ($kms_recorridos < 0) {
        $kms_recorridos = 0;
    }

    if (isset($zonas[$id])) {
        // Sumar por día
        if (!isset($zonas[$id]['Diario'][$dia])) {
            $zonas[$id]['Diario'][$dia] = 0;
        }
        $zonas[$id]['Diario'][$dia] += $kms_recorridos;

        // Sumar por semana
        if (!isset($zonas[$id]['Semanal'][$semana])) {
            $zonas[$id]['Semanal'][$semana] = 0;
        }
        $zonas[$id]['Semanal'][$semana] += $kms_recorridos;

        // Sumar por mes
        if (!isset($zonas[$id]['Mensual'][$mes])) {
            $zonas[$id]['Mensual'][$mes] = 0;
        }
        $zonas[$id]['Mensual'][$mes] += $kms_recorridos;
    }
}

echo json_encode($zonas);
?>