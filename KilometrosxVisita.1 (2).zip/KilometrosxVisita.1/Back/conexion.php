<?php

$dbname="cliente16";
$dbuser="development";
$dbhost="masven.com.mx";
$dbpass="Daniel%2020";

$conexion=mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);

if ($conexion->connect_error) {
    die('Error de Conexión (' . $conexion->connect_errno . ') '
            . $conexion->connect_error);
}

mysqli_set_charset($conexion, "utf8mb4");
?>