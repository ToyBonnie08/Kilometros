<?php    
header('Content-Type: application/json');
include('conexion.php');


$sql = "SELECT id, Zona FROM tiporuta WHERE activo=1 AND LEFT(Zona, 4)='Ruta' ORDER BY Zona ASC";
$result = $conexion->query($sql);

$zonas = [];
while ($row = $result->fetch_assoc()) {
    $zonas[$row['id']] = [
        'Zona' => $row['Zona'],
        'Kilometrajes' => [],
        'Visitas' => [],
        'KmsPorVisita' => [],
        'KmsPorVisita_Semanal' => [],
        'KmsPorVisita_Mensual' => []
    ];
}


$sqlkm = "SELECT tiporuta_id, DATE(fecha) AS dia, kmsinicial, kmsfinal FROM vehiculokms";
$resultkm = $conexion->query($sqlkm);

while ($row = $resultkm->fetch_assoc()) {
    $id = $row['tiporuta_id'];
    $dia = $row['dia'];
    $kms_inicial = (float)$row['kmsinicial'];
    $kms_final = (float)$row['kmsfinal'];

    $kms_recorridos = $kms_final - $kms_inicial;
    if ($kms_recorridos < 0) {
        $kms_recorridos = 0;
    }

    if (isset($zonas[$id])) {
        $zonas[$id]['Kilometrajes'][$dia] = $kms_recorridos;
    }
}


$sqlVisitas = "
    SELECT a.fecha, a.TipoRuta_Id, COUNT(c.visita_id) AS total_visitas
    FROM ruta a
    LEFT JOIN visita_tareas c ON a.Id = c.Ruta_Id
    GROUP BY a.fecha, a.TipoRuta_Id
    ORDER BY a.fecha DESC
";

$resultVisitas = $conexion->query($sqlVisitas);

while ($row = $resultVisitas->fetch_assoc()) {
    $id = $row['TipoRuta_Id'];
    $fecha = $row['fecha'];
    $visitas = (int)$row['total_visitas'];

    if (isset($zonas[$id])) {
        $zonas[$id]['Visitas'][$fecha] = $visitas;
    }
}


foreach ($zonas as $id => &$zona) {
    foreach ($zona['Kilometrajes'] as $fecha => $kms) {
        $visitas = isset($zona['Visitas'][$fecha]) ? $zona['Visitas'][$fecha] : 0;
        $zona['KmsPorVisita'][$fecha] = ($visitas > 0) ? round($kms / $visitas, 2) : null;
    }

 
    $semana_temp = [];
    $mes_temp = [];

    foreach ($zona['KmsPorVisita'] as $fecha => $kpv) {
        if ($kpv === null) continue;

        $timestamp = strtotime($fecha);
        $semana = date("o-W", $timestamp); 
        $mes = date("Y-m", $timestamp);   

       
        if (!isset($semana_temp[$semana])) {
            $semana_temp[$semana] = ['kms' => 0, 'visitas' => 0];
        }
        $semana_temp[$semana]['kms'] += $zona['Kilometrajes'][$fecha];
        $semana_temp[$semana]['visitas'] += $zona['Visitas'][$fecha];

       
        if (!isset($mes_temp[$mes])) {
            $mes_temp[$mes] = ['kms' => 0, 'visitas' => 0];
        }
        $mes_temp[$mes]['kms'] += $zona['Kilometrajes'][$fecha];
        $mes_temp[$mes]['visitas'] += $zona['Visitas'][$fecha];
    }

    
    foreach ($semana_temp as $semana => $data) {
        $zona['KmsPorVisita_Semanal'][$semana] = ($data['visitas'] > 0) ? round($data['kms'] / $data['visitas'], 2) : null;
    }


    foreach ($mes_temp as $mes => $data) {
        $zona['KmsPorVisita_Mensual'][$mes] = ($data['visitas'] > 0) ? round($data['kms'] / $data['visitas'], 2) : null;
    }
}


echo json_encode(array_values($zonas));
?>