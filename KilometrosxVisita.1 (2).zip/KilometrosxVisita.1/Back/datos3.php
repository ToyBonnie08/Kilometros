<?php      
header('Content-Type: application/json');
include('conexion.php'); // Asegúrate de que 'conexion.php' tenga la configuración de la base de datos

// Consulta para obtener las rutas activas que empiezan con "Ruta"
$sql = "SELECT id, Zona FROM tiporuta WHERE activo=1 AND LEFT(Zona, 4)='Ruta' ORDER BY Zona ASC";
$result = $conexion->query($sql);

// Verificación de la consulta
if (!$result) {
    die('Error ejecutando la consulta de rutas: ' . $conexion->error);
}

$zonas = [];
while ($row = $result->fetch_assoc()) {
    $zonas[$row['id']] = [
        'Zona' => $row['Zona'],
        'horas' => [], // en minutos ahora
        'Visitas' => [],
        'HorasPorVisita' => [], // minutos por visita
        'HorasPorVisita_Semanal' => [],
        'HorasPorVisita_Mensual' => []
    ];
}

// Consulta para obtener los kilómetros recorridos por vehículo y el tiempo
$sqlkm = "SELECT tiporuta_id, DATE(fecha) AS dia, TIME(fecha) AS hora, TIME(fecha_regreso) AS hora_regreso FROM vehiculokms";
$resultkm = $conexion->query($sqlkm);

// Verificación de la consulta
if (!$resultkm) {
    die('Error ejecutando la consulta de km: ' . $conexion->error);
}

while ($row = $resultkm->fetch_assoc()) {
    $id = $row['tiporuta_id'];
    $dia = $row['dia'];
    
    // Verificamos si tenemos ambos valores de hora (salida y regreso)
    if (empty($row['hora_regreso']) || empty($row['hora'])) {
        $minutos_recorridos = 0;  // Si no hay hora de regreso, se asignan 0 minutos
    } else {
        // Si ambos están presentes, calculamos el tiempo
        $hora_inicial = new DateTime($row['hora']);
        $hora_final = new DateTime($row['hora_regreso']);
        
        // Si la hora final es menor que la inicial, se asume que pasó a medianoche
        if ($hora_final < $hora_inicial) {
            $hora_final->modify('+1 day');
        }

        // Calcular la diferencia en minutos
        $intervalo = $hora_inicial->diff($hora_final);
        $minutos_recorridos = ($intervalo->h * 60) + $intervalo->i;

        // Asegurarse de que no sea negativo
        if ($minutos_recorridos < 0) {
            $minutos_recorridos = 0;
        }
    }

    // Asignar los minutos recorridos al array correspondiente a la ruta
    if (isset($zonas[$id])) {
        $zonas[$id]['horas'][$dia] = $minutos_recorridos;
    }
}

// Consulta para obtener el total de visitas por ruta y fecha
$sqlVisitas = "
    SELECT a.fecha, a.TipoRuta_Id, COUNT(c.visita_id) AS total_visitas
    FROM ruta a
    LEFT JOIN visita_tareas c ON a.Id = c.Ruta_Id
    GROUP BY a.fecha, a.TipoRuta_Id
    ORDER BY a.fecha DESC
";
$resultVisitas = $conexion->query($sqlVisitas);

// Verificación de la consulta
if (!$resultVisitas) {
    die('Error ejecutando la consulta de visitas: ' . $conexion->error);
}

while ($row = $resultVisitas->fetch_assoc()) {
    $id = $row['TipoRuta_Id'];
    $fecha = $row['fecha'];
    $visitas = (int)$row['total_visitas'];

    // Asignar el total de visitas al array correspondiente a la ruta
    if (isset($zonas[$id])) {
        $zonas[$id]['Visitas'][$fecha] = $visitas;
    }
}

// Calcular "HorasPorVisita" (minutos por visita) para cada ruta
foreach ($zonas as $id => &$zona) {
    foreach ($zona['horas'] as $fecha => $minutos) {
        $visitas = isset($zona['Visitas'][$fecha]) ? $zona['Visitas'][$fecha] : 0;
        $zona['HorasPorVisita'][$fecha] = ($visitas > 0) ? round($minutos / $visitas, 2) : null;
    }

    // Inicializar arrays temporales para las semanas y meses
    $semana_temp = [];
    $mes_temp = [];

    foreach ($zona['HorasPorVisita'] as $fecha => $mpv) {
        if ($mpv === null) continue;

        // Obtener la semana y el mes correspondientes
        $timestamp = strtotime($fecha);
        $semana = date("o-W", $timestamp);  // Año y número de la semana (ISO-8601)
        $mes = date("Y-m", $timestamp);    // Año y mes

        // Agregar minutos y visitas por semana
        if (!isset($semana_temp[$semana])) {
            $semana_temp[$semana] = ['minutos' => 0, 'visitas' => 0];
        }
        $semana_temp[$semana]['minutos'] += $zona['horas'][$fecha];
        $semana_temp[$semana]['visitas'] += $zona['Visitas'][$fecha];

        // Agregar minutos y visitas por mes
        if (!isset($mes_temp[$mes])) {
            $mes_temp[$mes] = ['minutos' => 0, 'visitas' => 0];
        }
        $mes_temp[$mes]['minutos'] += $zona['horas'][$fecha];
        $mes_temp[$mes]['visitas'] += $zona['Visitas'][$fecha];
    }

    // Calcular "HorasPorVisita_Semanal" (minutos por visita semanal)
    foreach ($semana_temp as $semana => $data) {
        $zona['HorasPorVisita_Semanal'][$semana] = ($data['visitas'] > 0) ? round($data['minutos'] / $data['visitas'], 2) : null;
    }

    // Calcular "HorasPorVisita_Mensual" (minutos por visita mensual)
    foreach ($mes_temp as $mes => $data) {
        $zona['HorasPorVisita_Mensual'][$mes] = ($data['visitas'] > 0) ? round($data['minutos'] / $data['visitas'], 2) : null;
    }
}

// Devolver los datos en formato JSON
echo json_encode(array_values($zonas));

?>